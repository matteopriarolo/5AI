class Main {
    public static void main(String[] args) {
        JFrame1 mioFrame = new JFrame1("Finestra1", "finestra1", 300, 200);
        JFrame1 mioFrame2 = new JFrame1("Finestra2", "finestra2", 300, 200);
    }
}