import java.io.*;
class Main{
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Inserisci il percorso del file o della cartella: ");
        String percorso = br.readLine();

        File file = new File(percorso);

        BufferedWriter fw = new BufferedWriter(new FileWriter("output.txt"));
        

        // se il percorso è una cartella o un file
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                System.out.println(f.getName());
                fw.write(f.getName() + "\n");
            }
        } else if (file.isFile()) {
            System.out.println("Il percorso è un file.");
        } else {
            System.out.println("Il percorso specificato non esiste.");
        }

        fw.close();
        br.close();

    }
}


// se è cartella o file
// stampale elenco completo dei file